/*

Copyright 2024 Massimo Santini

This file is part of "Programmazione 2 @ UniMI" teaching material.

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This material is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this file.  If not, see <https://www.gnu.org/licenses/>.

 */
package clients;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import borsanova.Borsa;

/**
 * Client di test per alcune funzionalità relative alle
 * <strong>aziende</strong>.
 */
public class OmonimiaBorsaClient {

    /**
     * .
     */
    private OmonimiaBorsaClient() {
    }

    /*-
   * Scriva un {@code main} che legge dal flusso di ingresso una sequenza di
   * linee, ciascuna delle quali corrispondente ad un nome di borsa ed emette
   * nel flusso d'uscita l'elenco di tali nomi di borsa in ordine alfabetico e
   * senza ripetizioni.
     */
    public static void main(String[] args) {
        Set<Borsa> borsecorrenti = new TreeSet<>();

        try (Scanner s = new Scanner(System.in)) {
            while (s.hasNextLine()) {
                try {
                    borsecorrenti.add(Borsa.of(s.nextLine()));
                } catch (IllegalArgumentException e) {
                }
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

        for (Borsa borsa : borsecorrenti) {
            System.out.println(borsa.name);
        }
    }

}
