package borsanova;

/**
 * Record per la rappresentazione di un'allocazione di azioni.
 * 
 * @param operatore    operatore che ha allocato le azioni.
 * @param azione       azione allocata.
 * @param numeroazioni numero di azioni allocate.
 */
public record Allocazione(Operatore operatore, Azione azione, int numeroazioni) {

    /**
     * Costruttore di default
     *
     * @throws IllegalArgumentException se il numero di azioni allocate è negativo.
     */
    public Allocazione {
        if (numeroazioni < 0) {
            throw new IllegalArgumentException("Il numero di azioni allocate non può essere negativo");
        }
    }

    /**
     * Metodo che restituisce l'azione allocata.
     *
     * @return l'azione allocata.
     */
    public Azione getAzione() {
        return azione;
    }

    /**
     * Metodo che restituisce il numero di azioni allocate.
     *
     * @return il numero di azioni allocate.
     */
    public int getNumeroAzioni() {
        return numeroazioni;
    }

    /**
     * Metodo che restituisce l'operatore a cui appartiene l'allocazione.
     *
     * @return l'operatore che ha allocato le azioni.
     */
    public Operatore getOperatore() {
        return operatore;
    }

}
